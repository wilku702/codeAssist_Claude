import os
import subprocess
import unittest

from gradescope_utils.autograder_utils.decorators import weight, visibility, number

_TEST_CASES_FOLDER = 'a2_cases'
_CMD = ['python3', '-u', 'intervals.py']
_TIME_LIMIT = 10


class TestIntervals(unittest.TestCase):

    @number('1')
    @weight(6.0)
    def test_case_1(self):
        """Sample Test Case 1"""
        actual_out = run_test_case('input000.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output000.txt')

        print('Input:')
        print(open(f'a2_cases/input000.txt', 'r').read())
        print()
        print('Expected Output:')
        print(expected_out)
        print()
        print('Your Output:')
        print(actual_out)

        self.assertEqual(expected_out, actual_out)

    @number('2')
    @weight(6.0)
    def test_case_2(self):
        """Sample Test Case 2"""
        actual_out = run_test_case('input001.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output001.txt')

        print('Input:')
        print(open(f'a2_cases/input001.txt', 'r').read())
        print()
        print('Expected Output:')
        print(expected_out)
        print()
        print('Your Output:')
        print(actual_out)

        self.assertEqual(expected_out, actual_out)

    @number('3')
    @weight(6.0)
    def test_case_3(self):
        """Sample Test Case 3"""
        actual_out = run_test_case('input002.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output002.txt')

        print('Input:')
        print(open(f'a2_cases/input002.txt', 'r').read())
        print()
        print('Expected Output:')
        print(expected_out)
        print()
        print('Your Output:')
        print(actual_out)

        self.assertEqual(expected_out, actual_out)

    @number('4')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_4(self):
        """Test case 4"""
        actual_out = run_test_case('input003.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output003.txt')

        print('Input:')
        print(open(f'a2_cases/input003.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output003.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)

        self.assertTrue(expected_out == actual_out)

    @number('5')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_5(self):
        """Test case 5"""
        actual_out = run_test_case('input004.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output004.txt')

        print('Input:')
        print(open(f'a2_cases/input004.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output004.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)

        self.assertTrue(expected_out == actual_out)

    @number('6')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_6(self):
        """Test case 6"""
        actual_out = run_test_case('input005.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output005.txt')

        print('Input:')
        print(open(f'a2_cases/input005.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output005.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)


        self.assertTrue(expected_out == actual_out)

    @number('7')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_7(self):
        """Test case 7"""
        actual_out = run_test_case('input006.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output006.txt')

        print('Input:')
        print(open(f'a2_cases/input006.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output006.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)


        self.assertTrue(expected_out == actual_out)

    @number('8')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_8(self):
        """Test case 8"""
        actual_out = run_test_case('input007.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output007.txt')

        print('Input:')
        print(open(f'a2_cases/input007.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output007.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)

        self.assertTrue(expected_out == actual_out)

    @number('9')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_9(self):
        """Test case 9"""
        actual_out = run_test_case('input008.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output008.txt')

        print('Input:')
        print(open(f'a2_cases/input008.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output008.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)

        self.assertTrue(expected_out == actual_out)

    @number('10')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_10(self):
        """Test case 10"""
        actual_out = run_test_case('input009.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output009.txt')

        print('Input:')
        print(open(f'a2_cases/input009.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output009.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)

        self.assertTrue(expected_out == actual_out)

    @number('11')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_11(self):
        """Test case 11"""
        actual_out = run_test_case('input010.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output010.txt')

        print('Input:')
        print(open(f'a2_cases/input010.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output010.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)

        self.assertTrue(expected_out == actual_out)

    @number('12')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_12(self):
        """Test case 12"""
        actual_out = run_test_case('input011.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output011.txt')

        print('Input:')
        print(open(f'a2_cases/input011.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output011.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)

        self.assertTrue(expected_out == actual_out)

    @number('13')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_13(self):
        """Test case 13"""
        actual_out = run_test_case('input012.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output012.txt')

        print('Input:')
        print(open(f'a2_cases/input012.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output012.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)

        self.assertTrue(expected_out == actual_out)

    @number('14')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_14(self):
        """Test case 14"""
        actual_out = run_test_case('input013.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output013.txt')

        print('Input:')
        print(open(f'a2_cases/input013.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output013.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)

        self.assertTrue(expected_out == actual_out)

    @number('15')
    @weight(6.0)
    #@visibility('after_published')
    def test_case_15(self):
        """Test case 15"""
        actual_out = run_test_case('input015.txt', _CMD, _TIME_LIMIT)
        expected_out = get_expected_out('output015.txt')

        print('Input:')
        print(open(f'a2_cases/input015.txt', 'r').read())
        print()
        #print('Expected Output:')
        #print(open(f'a2_cases/output015.txt', 'r').read())
        #print()
        print('Your Output:')
        print(actual_out)

        self.assertTrue(expected_out == actual_out)


def run_test_case(test_file, cmd, timeout):
    """Runs the test in given test file and returns the output if any.

    Fetches the test case from given test file, and executes the running
    the test command with given time limit.

    Args:
        test_file:
            A file name inside the test cases folder containing the test case.
        cmd:
            A list of string used to run the submitted program.
        timeout:
            An integer indicate the time limit for each test case in seconds.

    Returns:
        A string of the output from running the program,
        None if time limit exceeded.
    """
    with open(os.path.join(_TEST_CASES_FOLDER, test_file)) as file:
        content = file.read()
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stdin=subprocess.PIPE)
        try:
            _input = bytes(content, encoding='utf-8')
            out, error = p.communicate(input=_input, timeout=_TIME_LIMIT)
            p.kill()
            return out.decode('utf-8').strip()
        except subprocess.TimeoutExpired as e:
            print('Time Limit Exceeded')
            p.kill()
            return None


def get_expected_out(output_file):
    """Fetches the expected output from given file."""
    with open(os.path.join(_TEST_CASES_FOLDER, output_file)) as file:
        return file.read()


if __name__ == '__main__':
    unittest.main()
